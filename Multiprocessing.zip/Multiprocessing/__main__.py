import numpy as np
import pandas as pd
from datetime import datetime
import os 
from pmdarima import auto_arima
from statsmodels.tsa.statespace.sarimax import SARIMAX
from statsmodels.tsa.stattools import adfuller

from statsforecast.models import TSB
from statsforecast.models import Holt
from statsforecast.models import HoltWinters
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from tqdm.autonotebook import tqdm
from prophet import Prophet
from prophet.plot import add_changepoints_to_plot

from sklearn.preprocessing import MinMaxScaler
from keras.models import Sequential
from keras.layers import LSTM
from keras.layers import Dense
from keras.layers import SimpleRNN
from keras.layers import Dropout
from keras.layers import GRU, Bidirectional
from keras.optimizers import SGD
from sklearn import metrics
from sklearn.metrics import mean_squared_error

import re
import warnings
# from pyinstrument import Profiler
from multiprocessing import Queue, Manager
import logging
import multiprocessing
import psutil



# As arima and HOLT requires vertical dataframes in this function we are converting our horizotal dataframe to vertical dataframe

def vertical_df(data, forecast_start, queue, name):
     
    log_file = f"process_{name}.log"
    logging.basicConfig(filename= log_file, level=logging.INFO)  
    logger = logging.getLogger(__name__)  
    # item_df_demand = data.pivot_table(index=['ItemCode', 'Year'], values='DemandQty')
    print(data)
    item_df_issue = data.pivot_table(index=['ItemCode',  'Year'], values='IssueQty')
    print(item_df_issue)
    # item_df_lead = data.pivot_table(index=['ItemCode',  'Year'], values='LeadTime')
    # non_zero_item_df_demand = item_df_demand[item_df_demand['DemandQty'] != 0]
    non_zero_item_df_issue = item_df_issue[item_df_issue['IssueQty'] != 0]
    print(non_zero_item_df_issue)
    # non_zero_item_df_lead = item_df_lead[item_df_lead['LeadTime'] != 0]
    # print(non_zero_item_df_demand)
    # print(non_zero_item_df_issue)
    # print(non_zero_item_df_lead)
    # data['IssueNacQty'] = data['IssueQty'] + data['DemandQty'] + data['LeadTime']
    data['IssueNacQty'] = data['IssueQty']
    # data['IssueNacQty'] = data['DemandQty']
    item_df_issueNAC = data.pivot_table(index=['ItemCode',  'Year'], values='IssueNacQty')
    non_zero_item_df_issueNAC = item_df_issueNAC[item_df_issueNAC['IssueNacQty'] != 0]
    # print(item_df_demand)
    # print(item_df_issue)
    # print(item_df_issueNAC)
    
    current_folder = os.getcwd()
    path_to_output = os.path.join(current_folder, "output")
    if not os.path.exists(path_to_output):
        os.makedirs(path_to_output)
        
    # non_zero_item_df_demand.to_excel(os.path.join(path_to_output, f'Non_Zero_Vertical_Usage_df_demands_{forecast_start}.xlsx'))
    non_zero_item_df_issue.to_excel(os.path.join(path_to_output, f'Non_Zero_Vertical_Usage_df_issues_{forecast_start}.xlsx'))
    # non_zero_item_df_lead.to_excel(os.path.join(path_to_output, f'Non_Zero_Vertical_Usage_df_lead_{forecast_start}.xlsx'))
    non_zero_item_df_issueNAC.to_excel(os.path.join(path_to_output, f'Non_Zero_Vertical_Usage_df_issueNAC_{forecast_start}.xlsx'))
    # item_df_demand.to_excel(os.path.join(path_to_output, f'Vertical_Usage_df_demands_{forecast_start}.xlsx'))
    item_df_issue.to_excel(os.path.join(path_to_output, f'Vertical_Usage_df_issue_{forecast_start}.xlsx'))
    # item_df_lead.to_excel(os.path.join(path_to_output, f'Vertical_Usage_df_lead_{forecast_start}.xlsx'))
    item_df_issueNAC.to_excel(os.path.join(path_to_output, f'Vertical_Usage_df_issueNAC_{forecast_start}.xlsx'))
    
    return non_zero_item_df_issueNAC





# This is code for ARIMA

def arima(Non_Zero_Vertical_usage_df_issues, forecast_start, forecast_end, start_year, adp_combine_start, adp_combine_end, pivot_table, 
          start_p, start_q, max_p, max_q, m, start_P, seasonal, d, D, trace, error_action, suppress_warnings, stepwise, n_jobs, queue, name):
    warnings.filterwarnings("ignore")
    log_file = f"process_{name}.log"
    logging.basicConfig(filename=log_file, level=logging.INFO)  
    logger = logging.getLogger(__name__)  
    # print(Non_Zero_Vertical_usage_df_issues)
    for item in Non_Zero_Vertical_usage_df_issues.index.get_level_values('ItemCode').unique():    
        try:
            print(f'****** THE NEXT ITEM TO BE ANALYSED IS - {item}')
            Vertical_usage_df_issues_one_item = Non_Zero_Vertical_usage_df_issues.loc[Non_Zero_Vertical_usage_df_issues.index.get_level_values('ItemCode')==item]             
            Vertical_usage_df_issues_one_item = Vertical_usage_df_issues_one_item.sort_values(by = ['ItemCode','Year'], ascending = [True,True])
            # print(Vertical_usage_df_issues_one_item)
            data = Vertical_usage_df_issues_one_item[['IssueNacQty']].reset_index()
            data = data[['Year', 'IssueNacQty']]
            # print(data)
            data.replace(0,0.0000000001, inplace =True)# just to ensure that is there is a zero value it is replaced by a very small value, so that ARIMA can be used
        
            data['Ln_Issue_NAC'] = np.log(data[['IssueNacQty']])
            # print(data) 
            data['Ln_Issue_NAC'].dropna(inplace = True)
            # print(data) 
    
            
            for year in range(forecast_start, forecast_end):
                consumption_series = data['Ln_Issue_NAC'][0:(year - start_year)].copy()
                # print(f'Data fed to the system = {data.IssueNacQty[0:(year - start_year)]}')
        
    
                # stepwise_fit = auto_arima(consumption_series, start_p = 1, start_q = 1,
                #                           max_p = 20, max_q = 20, m = 1,
                #                           start_P = 0, seasonal = False,
                #                           d = None, D = 1, trace = True,
                #                           error_action ='ignore',   # we don't want to know if an order does not work
                #                           suppress_warnings = True,  # we don't want convergence warnings
                #                           stepwise = False,n_jobs = -1)           # set to stepwise
    
                
                stepwise_fit = auto_arima(consumption_series, start_p = start_p, start_q = start_q,
                                          max_p = max_p, max_q = max_q, m = m,
                                          start_P = start_P, seasonal = seasonal,
                                          d = d, D = D, trace = trace,
                                          error_action = error_action,   
                                          suppress_warnings = suppress_warnings,  
                                          stepwise = stepwise, n_jobs = n_jobs)           
    
                # To #print the summary
                # stepwise_fit.summary()
                stepwise_fit.order # this holds the best model order, we use this in the SARIMA model for forecasting
        
                train = consumption_series[0:(year - start_year - 1)].copy()
                # print(train)
                test = consumption_series[(year - start_year - 1) : (year - start_year)]
                # print(test)
        
                model = SARIMAX(train, 
                                order = stepwise_fit.order, # the previous step give this best model... this is one of the output for the AUTO_ARIMA
                                seasonal_order =(0,0,0,0))
        
                result = model.fit()
        
                start = len(train)
                #print(f'Start = {start}')
                end = len(train) + len(test)
                #print(f'end = {end}')
        
                # Predictions for one-year against the test set
                predictions = result.predict(start, end,
                                             typ = 'levels').rename("Predictions")
        
                # converting the values to normal, because-- to make them stationary we had used log of the number... now exp of the log
                df = np.exp(predictions)
                #print(f' Predictions  = \n{data.Issue_NAC[15:16]}')
                #print(f' Actual_values  = \n{df}')
                # print(f'df printing = {df}')
                ### NOW I HAVE TO CAPTURE THE ERROR FOR EACH YEAR...
        
                for idx, value in df.items():
                    prediction_forecast = float(df.at[idx])
                    pivot_table.loc[item, f'ARIMA_Val_{year}'] = prediction_forecast       
        
        
                if prediction_forecast < 0 :
                    prediction_forecast = 0
        
        
                for items in data.IssueNacQty[(year - start_year):(year - start_year + 1)]:
                    ARIMA_error_forecast = float(items - prediction_forecast)
                    pivot_table.loc[item, f'ARIMA_Error_{year}'] = ARIMA_error_forecast       
    
    
                if year >= adp_combine_start and year <=  adp_combine_end:
                    predictions = result.predict(start, end + (adp_combine_end - year),typ = 'levels').rename("Predictions")
                    df_combine = np.exp(predictions)
                    for next in range(year+1, adp_combine_end):
                        dynamic_vars = {}
                        key = f'ARIMA_{year - start_year}_{next - start_year}'                    
                        # Store the value in the dictionary
                        dynamic_vars[key] = float(df_combine.at[next - start_year])
                        # print(dynamic_vars)
                        
                        for key, value in dynamic_vars.items():
                          pivot_table.loc[item, key] = value        
            print(pivot_table)
            
        except Exception as e:
            # Handle the exception here, you can print an error message, log it, or take other actions
            print(f"Error in row : {e}")
            # You can also continue to the next row if you want to skip the current one
            continue
        # except AnotherException as e:
        #     print(f"Another error in row: {e}")
        #     # Handle another type of exception        
        #     continue
                
        current_folder = os.getcwd()
        path_to_output = os.path.join(current_folder, "output")
        if not os.path.exists(path_to_output):
            os.makedirs(path_to_output)
        
    pivot_table.to_excel(os.path.join(path_to_output, f'ARIMA_{forecast_start}.xlsx'),index = False, index_label = False)
    queue.put(pivot_table)
    return pivot_table




# This is code for holt

def holt_crostons(Non_Zero_Vertical_usage_df_issues, Tsb_alpha, season_length, error_type, h, alpha_p, forecast_start, forecast_end, 
                  start_year, adp_combine_start, adp_combine_end, pivot_table, queue, name):
        # Non_Zero_Vertical_usage_df_issues =Non_Zero_Vertical_usage_df_issues.loc[Non_Zero_Vertical_usage_df_issues.index.get_level_values('ItemCode')!='A'] 
        # print(Non_Zero_Vertical_usage_df_issues)
    log_file = f"process_{name}.log"
    logging.basicConfig(filename=log_file, level=logging.INFO)  
    logger = logging.getLogger(__name__)  

    for item in Non_Zero_Vertical_usage_df_issues.index.get_level_values('ItemCode').unique():    
        try:   
            print(f'****** THE NEXT ITEM TO BE ANALYSED IS - {item}')
            Vertical_usage_df_issues_one_item = Non_Zero_Vertical_usage_df_issues.loc[Non_Zero_Vertical_usage_df_issues.index.get_level_values('ItemCode')==item]             
            Vertical_usage_df_issues_one_item = Vertical_usage_df_issues_one_item.sort_values(by = ['ItemCode','Year'], ascending = [True,True])
            # print(Vertical_usage_df_issues_one_item)
            data = Vertical_usage_df_issues_one_item[['IssueNacQty']].reset_index()
            data = data[['Year', 'IssueNacQty']]
            # print(data)
                
            for year in range(forecast_start, forecast_end):
                print(f'*** Analysis for the error_for_ {year - start_year} ***')    
                consumption = data["IssueNacQty"][0:(year - start_year)].copy()
                consumption = consumption.to_numpy(dtype ='float32')
                # print(consumption)
                model = Holt(season_length=season_length, error_type=error_type)
                # print(model)
                model = model.fit(y=consumption)
                y_hat_dict = model.predict(h=h)
                
                for i in y_hat_dict:
                    x = float(y_hat_dict[i])
                    # print(f'holt_val_{year} = {x}')
                    pivot_table.loc[item, f'Holt_Val_{year}'] = x       
        
                if x<0 :
                    x=0
        
                # print(f'Actual_value = {float(data.IssueNacQty[(year - start_year):(year - start_year + 1)])}')
                Holt_error = float(data.IssueNacQty[(year - start_year):(year - start_year + 1)]) - x
                pivot_table.loc[item, f'Holt_Error_{year}'] = Holt_error      
                # print(f'Holt_Error_{year} = {Holt_error}')
                

                
        
        # *****************************************************############# TSB's model - CROSTONS METHOD
        
                model = TSB(alpha_d=Tsb_alpha, alpha_p=alpha_p)
                model = model.fit(y=consumption)
                y_hat_dict = model.predict(h=h)
        
        
                for i in y_hat_dict:
                    x = float(y_hat_dict[i])
                    pivot_table.loc[item, f'TSB_Val_{year}'] = x                      
                    # print(f'TSB_val_{year} = {x}')
        
                if x<0 :
                    x=0
        
                TSB_error= float(data.IssueNacQty[(year - start_year):(year - start_year + 1)]) - x
                pivot_table.loc[item, f'TSB_Error_{year}'] = TSB_error                                      
                # print(f'TSB_Error_{year} = {TSB_error}')

                if year >= adp_combine_start and year <=  adp_combine_end:
                    y_hat_dict = model.predict(h=(adp_combine_end - year))
                    for next in range(year+1, adp_combine_end):
                        index = 1
                        dynamic_vars = {}
                        forecast_arr = y_hat_dict['mean']
                        key = f'TSB_{year - start_year}_{next - start_year}'                    
                        # Store the value in the dictionary
                        dynamic_vars[key] = forecast_arr[index]
                        index = index + 1
                        # print(dynamic_vars)
                        
                        for key, value in dynamic_vars.items():
                            pivot_table.loc[item, key] = value        

            print(pivot_table)
        except Exception as e:
            # Handle the exception here, you can print an error message, log it, or take other actions
            print(f"Error in row : {e}")
            # You can also continue to the next row if you want to skip the current one
            continue
        # except AnotherException as e:
        #     print(f"Another error in row: {e}")
        #     # Handle another type of exception        
        #     continue 
            
    current_folder = os.getcwd()
    path_to_output = os.path.join(current_folder, "output")
    if not os.path.exists(path_to_output):
        os.makedirs(path_to_output)
    
    pivot_table.to_excel(os.path.join(path_to_output, f'HOLT_{forecast_start}.xlsx'),index = False, index_label = False)
    queue.put(pivot_table)
    return pivot_table





def fb_prophet(start_year, df, forecast_start, forecast_end, pivot_table, queue, name, smallest_pos_num):

    log_file = f"process_{name}.log"
    logging.basicConfig(filename=log_file, level=logging.INFO)  
    logger = logging.getLogger(__name__)  
    # df_grouped = pd.read_excel('C:\\Shreejay\\ACL Generation\\Original\\input\\Dem_data_test_section.xlsx')
    # df_grouped = df_grouped.fillna(smallest_pos_num)
    # df = df_grouped.groupby(['ItemCode', 'Year'])['IssueQty'].sum().reset_index()
    # df = df[["ItemCode", "Year", "IssueQty"]]
    # print(smallest_pos_num)
    # print(df)
    all_forecasts = []
    # print(df)
    
    
    for item in df['ItemCode'].unique():
        try:     
            df_1 = df.loc[df["ItemCode"] == item].copy()
            # print(df_1)
            
            # Convert the 'Year' to datetime format by adding a dummy date
            # df_1['year'] = pd.to_datetime(df_1['Year'], format='%Y')
            
            # df_1['ds_end'] = pd.to_datetime('31/12', format='%d/%m') 

            df_1['ds'] = pd.to_datetime(df_1['Year'].astype(str) + '-12-31', format='%Y-%m-%d')

            # print(f'df_1: {df_1}')
        
            # Rename the 'IssueQty' column to 'y'
            df_1.rename(columns={'IssueQty': 'y'}, inplace=True)
            df_1.reset_index(drop=True, inplace=True)
            # Keep only the required columns
            df_prophet = df_1[['ds', 'y']]
            # print(df_prophet)
            # df_prophet['ds'] = df_prophet['ds'].dt.year
            # print(f"DF_PROPHET_1: {df_prophet}")
            
            df_prophet_1 = df_prophet.loc[0:(forecast_start - start_year - 1)]
            # print(f"DF_PROPHET_1: {df_prophet_1}")
            m = Prophet()
            m.fit(df_prophet_1)
        
            future = m.make_future_dataframe(periods=(forecast_end - forecast_start+1),
                                            freq='Y') 
            forecast = m.predict(future)
            forecast['y'] = df_1['y']
            forecast['Error'] = forecast['y'] - forecast['yhat']
            # print(forecast[['ds', 'y', 'yhat', 'trend', 'Error']])
            forecast['ds'] = forecast['ds'].dt.year   
            year_filter = forecast['ds'] > 2015  # Select rows where year is 2015 or later
            forecast = forecast[year_filter] 
            for year in range(forecast_start, forecast_end):
                year_filter = forecast[forecast['ds'] == year]
                pivot_table.loc[item, f'FB_Prophet_Val_{year}'] = year_filter.iloc[0]['yhat']
                pivot_table.loc[item, f'FB_Prophet_Error_{year}'] = year_filter.iloc[0]['Error']
            
            all_forecasts.append(forecast[['ds', 'y', 'yhat', 'trend', 'Error']])
            # print(f"All Forecasts: {all_forecasts}")
            # Combine all forecasts into a single DataFrame
            combined_forecast = pd.concat(all_forecasts, ignore_index=True)
            # print(combined_forecast)
            current_folder = os.getcwd()
            path_to_output = os.path.join(current_folder, "output")
            if not os.path.exists(path_to_output):
                os.makedirs(path_to_output)
            combined_forecast.to_excel(os.path.join(path_to_output, f'FB_Prophet_{forecast_start}.xlsx'), index=False, index_label=False)
        
        except Exception as e:
            # Handle the exception here, you can print an error message, log it, or take other actions
            print(f"Error in row : {e}")
            # You can also continue to the next row if you want to skip the current one
            continue        

    logger.info(f"Pivot Table: {pivot_table}")
    queue.put(pivot_table)    
    return pivot_table
        
        # 'yhat_lower','yhat_upper', 'trend',
        # 'trend_lower', 'trend_upper']])
        # print(forecast)


def simple_RNN(start_year, df_RNN, forecast_start, forecast_end, pivot_table, queue, name, smallest_pos_num):

    log_file = f"process_{name}.log"
    logging.basicConfig(filename=log_file, level=logging.INFO)  
    logger = logging.getLogger(__name__)      
    
    # df_RNN = pd.read_excel('D:\\Shreejay\\Projects\\MO\\ACLProject\\input\\Input_test_data_110723_lead.xlsx')
    # df_RNN_grouped = pd.read_excel('C:\\Shreejay\\ACL Generation\\Original\\input\\Dem_data_test_section.xlsx')
    # df_RNN = df_RNN_grouped.groupby(['ItemCode', 'Year'])['IssueQty'].sum().reset_index()
    # df_RNN = df_RNN[["ItemCode", "Year", "IssueQty"]]
    # df_RNN = df_RNN.fillna(smallest_pos_num)
    # tf.keras.models.load_model()
    print(df_RNN)
    
    # df_export = pd.read_excel('D:\\Shreejay\\Projects\\MO\\ACLProject\\input\\Input_test_data_110723_lead.xlsx')
    # pivot_table = df_export.pivot_table(index='ItemCode', columns='Year', values='IssueQty')
    # df_export = {};
    
    for item in df_RNN['ItemCode'].unique():
        try:                
            df_1 = df_RNN.loc[df_RNN["ItemCode"] == item].copy()
            df_1.reset_index(drop=True, inplace=True)
        
        
            #Splitting the dataset
            train_data = df_1['IssueQty'].loc[0:(forecast_start - start_year - 1)] 
            test_data = df_1['IssueQty'].loc[(forecast_start - start_year):(forecast_end - start_year)]
        
            # print(train_data.shape)
            # print(test_data.shape)
            dataset_train = np.reshape(train_data, (-1,1))
            # print(dataset_train)
            # print(dataset_train.shape)
            scaler = MinMaxScaler(feature_range=(0,1))
        
            # scaling dataset
            scaled_train = scaler.fit_transform(dataset_train)
            # print(scaled_train)
            
            dataset_test = np.reshape(test_data, (-1,1))
            # print(dataset_test)
            # print(dataset_test.shape)
            scaler = MinMaxScaler(feature_range=(0,1))
        
            # scaling dataset
            scaled_test = scaler.fit_transform(dataset_test)
            # print(scaled_test)
        
        
            
            X_train = []
            y_train = []
            for i in range(1, len(scaled_train)):
                X_train.append(scaled_train[i-1:i, 0])
                y_train.append(scaled_train[i, 0])
            # print(X_train)
            # print(y_train)
            
            X_test = []
            y_test = []
            for i in range(1, len(scaled_test)):
                X_test.append(scaled_test[i-1:i, 0])
                y_test.append(scaled_test[i, 0])
            
            # print(X_test)
            # print(y_test)
        
            # The data is converted to Numpy array
            X_train, y_train = np.array(X_train), np.array(y_train)
            
            #Reshaping
            X_train = np.reshape(X_train, (X_train.shape[0], X_train.shape[1],1))
            y_train = np.reshape(y_train, (y_train.shape[0],1))
            # print("X_train :",X_train.shape,"y_train :",y_train.shape)
        
        
            # The data is converted to numpy array
            X_test, y_test = np.array(X_test), np.array(y_test)
            
            #Reshaping
            X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1],1))
            y_test = np.reshape(y_test, (y_test.shape[0],1))
            # print("X_test :",X_test.shape,"y_test :",y_test.shape)
        
            ############################################################### Simple RNN #################################################################    
            # initializing the RNN
            regressor = Sequential()
            
            # adding RNN layers and dropout regularization
            regressor.add(SimpleRNN(units = 50, 
                                    activation = "tanh",
                                    return_sequences = True,
                                    input_shape = (X_train.shape[1],1)))
            regressor.add(Dropout(0.2))
            
            regressor.add(SimpleRNN(units = 50, 
                                    activation = "tanh",
                                    return_sequences = True))
            
            regressor.add(SimpleRNN(units = 50,
                                    activation = "tanh",
                                    return_sequences = True))
            
            regressor.add( SimpleRNN(units = 50))
            
            # adding the output layer
            regressor.add(Dense(units = 1,activation='sigmoid'))
            
            # compiling RNN
            regressor.compile(optimizer = SGD(learning_rate=0.01,
                                            decay=1e-6, 
                                            momentum=0.9, 
                                            nesterov=True), 
                            loss = "mean_squared_error")
            
            # fitting the model
            regressor.fit(X_train, y_train, epochs = 20, batch_size = 2)
            # regressor.summary()
        
            y_RNN = regressor.predict(X_test)
        
            # print(y_RNN)
            
            # scaling back from 0-1 to original
            y_RNN_O = scaler.inverse_transform(y_RNN) 
        
            # print(y_RNN_O)
        
            for year in range(forecast_start, forecast_end):
                y_rnn_offset = year - forecast_start
                pivot_table.loc[item, f"Simple_RNN_Val_{year}"] = y_RNN_O[y_rnn_offset]
                pivot_table.loc[item, f"Simple_RNN_Error_{year}"] = pivot_table.loc[item, year] - y_RNN_O[y_rnn_offset]
        
        except Exception as e:
            # Handle the exception here, you can print an error message, log it, or take other actions
            print(f"Error in row : {e}")
            # You can also continue to the next row if you want to skip the current one
            continue 
    current_folder = os.getcwd()
    path_to_output = os.path.join(current_folder, "output")
    if not os.path.exists(path_to_output):
        os.makedirs(path_to_output)
    pivot_table.to_excel(os.path.join(path_to_output, f'Simple_Neural_Network_{forecast_start}.xlsx'), index=False, index_label=False)
    queue.put(pivot_table)
    return pivot_table
    

def combined_method(pivot_table, forecast_start, forecast_end, queue, name):

    log_file = f"process_{name}.log"
    logging.basicConfig(filename=log_file, level=logging.INFO)  
    logger = logging.getLogger(__name__)      
    # df = pd.read_excel("D:\\Shreejay\\Projects\\MO\\ACL_VS\\ACL\\output\\Adp_ACL_2016.xlsx");
    # pivot_table = df.copy();
    error = []
    value_cols = []
    pattern = r'Val\d?'  # Matches "Error" followed by optional digit
    print(pivot_table.columns.tolist)
    for col in pivot_table.columns.tolist():
        if(re.search(pattern, str(col))):
            value_cols.append(str(col))
    pivot_table.loc[:, value_cols] = pivot_table.loc[:, value_cols].abs()
    for index, row in pivot_table.iterrows():
        for year in range(forecast_start, forecast_end):
            cols = []
            value_pattern = f"Val_{year}"  # Matches "Error" followed by optional digit
            for col in value_cols:
                if(re.search(value_pattern, col)):
                    cols.append(col)
            print(year)
            print(row[cols])
            avg = row[cols].mean()
            pivot_table.loc[index, f"Combined_Val_{year}"] = avg
            pivot_table.loc[index, f"Combined_Error_{year}"] = pivot_table.loc[index, year] - avg
    queue.put(pivot_table)            
    return pivot_table        


def find_best_method_per_year(pivot_table, forecast_start, forecast_end, queue, name):  


    log_file = f"process_{name}.log"
    logging.basicConfig(filename=log_file, level=logging.INFO)  
    logger = logging.getLogger(__name__)      
    # df = pd.read_excel("D:\\Shreejay\\Projects\\MO\\ACL_VS\\ACL\\output\\Overall_Results_2016.xlsx");
    # pivot_table = df.copy();
    error_cols = []
    error_pattern = r'Error\d?'  # Matches "Error" followed by optional digit
    for col in pivot_table.columns.tolist():
        if(re.search(error_pattern, str(col))):
            error_cols.append(str(col))
    pivot_table.loc[:, error_cols] = pivot_table.loc[:, error_cols].abs()
    for index, row in pivot_table.iterrows():
        for year in range(forecast_start, forecast_end):
            cols = []
            error_pattern = f"Error_{year}"  # Matches "Error" followed by optional digit
            for col in error_cols:
                if(re.search(error_pattern, col)):
                    cols.append(col)
            # print(year)
            # print(row[cols])
            min = row[cols].idxmin()
            pivot_table.loc[index, f"Best_of_{year}"] = min
    # print(pivot_table)            
    queue.put(pivot_table)    
    return pivot_table

def find_overall_best_method_per_year(pivot_table, forecast_start, forecast_end, queue, name):  


    log_file = f"process_{name}.log"
    logging.basicConfig(filename=log_file, level=logging.INFO)  
    logger = logging.getLogger(__name__)      
    # df = pd.read_excel("D:\\Shreejay\\Projects\\MO\\ACL_VS\\ACL\\output\\Overall_Results_2016.xlsx");
    # pivot_table = df.copy();
    error_cols = []
    error_pattern = r'Error\d?'  # Matches "Error" followed by optional digit
    for col in pivot_table.columns.tolist():
        if(re.search(error_pattern, str(col))):
            error_cols.append(str(col))
    pivot_table.loc[:, error_cols] = pivot_table.loc[:, error_cols].abs()
    for index, row in pivot_table.iterrows():
        for year in range(forecast_start, forecast_end):
            cols = []
            error_pattern = f"Error_{year}"  # Matches "Error" followed by optional digit
            for col in error_cols:
                if(re.search(error_pattern, col)):
                    cols.append(col)
            # print(year)
            # print(row[cols])
            min = row[cols].idxmin()
            pivot_table.loc[index, f"Best_of_{year}"] = min
    # print(pivot_table)            
    queue.put(pivot_table)    
    return pivot_table



def find_combined_error(pivot_table, forecast_start, forecast_end, no_of_years, queue, name):   
    # if(no_of_years < 2):
    #     print("No of years should be greater than 1")
    #     return "";
    # df = pd.read_excel("D:\\Shreejay\\Projects\\MO\\ACL_VS\\ACL\\output\\Adp_ACL_2016.xlsx");
    # pivot_table = df.copy();
    error_cols = []
    error_pattern = r'Error\d?'  # Matches "Error" followed by optional digit
    for col in pivot_table.columns.tolist():
        if(re.search(error_pattern, str(col))):
            error_cols.append(str(col))
    pivot_table.loc[:, error_cols] = pivot_table.loc[:, error_cols].abs()
    for index, row in pivot_table.iterrows():
        patterns = ["Adp_Acl", "FB_Prophet", "ARIMA", "Holt", "TSB", "Simple_RNN", "Old_Acl", "Combined"]
        for pattern in patterns:
            quantity = []
            for col1 in error_cols:
                if(re.search(pattern, col1)):
                    quantity.append(col1)
            min = []
            cols = []
            for year in range(forecast_start, forecast_start+no_of_years):
                error_pattern = f"Error_{year}"  # Matches "Error" followed by optional digit
                for col in quantity:
                    if(re.search(error_pattern, col)):
                        cols.append(col)
                # print(year)
                # print(row[cols])
                min = (row[cols].sum())
            pivot_table.loc[index, f"{pattern}_CombineError_{forecast_start}_{forecast_start + no_of_years}"] = min
            # print(min)
        best_of = []
        for pattern in patterns:
            error_value = pivot_table.loc[index, f"{pattern}_CombineError_{forecast_start}_{forecast_start + no_of_years}"]
            data_dict = {f"{pattern}_CombineError_{forecast_start}_{forecast_start + no_of_years}": error_value}
            best_of.append(data_dict)
        list_df = pd.DataFrame(best_of)
        combined_df = pd.DataFrame([list_df.stack().to_dict()])
        # print(combined_df)
        min_value = combined_df.min()
        # print(min_value)
            # error_pattern = f"Error_{year}"            
    # print(pivot_table)            
    queue.put(pivot_table)    
    return pivot_table



def find_best_combined_method(pivot_table, forecast_start, forecast_end, no_of_years, queue, name):
    # for index, row in pivot_table.iterrows():
    # error_cols = []
    # error_pattern = r'Error\d?'  # Matches "Error" followed by optional digit
    # for col in pivot_table.columns.tolist():
    #     if(re.search(error_pattern, str(col))):
    #         error_cols.append(str(col))
    error_cols = []
    # print(pivot_table)
    error_pattern = r'CombineError\d?'  # Matches "Error" followed by optional digit
    for col in pivot_table.columns.tolist():
        if(re.search(error_pattern, str(col))):
            error_cols.append(str(col))
    # print(error_cols)
    pivot_table.loc[:, error_cols] = pivot_table.loc[:, error_cols].abs()
    for index, row in pivot_table.iterrows():
        cols = []
        for col in error_cols:
            if(re.search(error_pattern, col)):
                cols.append(col)
        # print(year)
        # print(row[cols])
        min = row[cols].idxmin()
        pivot_table.loc[index, f"Best_of_{forecast_start}_{forecast_start + no_of_years}"] = min
    queue.put(pivot_table)        
    return pivot_table






# Lead Time
def calculation_of_lead_time(pivot_table, forecast_start, forecast_end):
    
    pivot_table = pivot_table['LeadTime'].fillna(0)























def old_acl_calculation(pivot_table, forecast_start, forecast_end, queue, name):
    for year in range(forecast_start, forecast_end):
        p_values_index = pivot_table.loc[:, year-5 : year-1]  # Assuming year is defined somewhere
        # Assuming p_values is your actual values DataFrame, replace it with your actual DataFrame name
        acl = (1 * p_values_index.iloc[:, 0] + 
               2 * p_values_index.iloc[:, 1] + 
               2 * p_values_index.iloc[:, 2] + 
               3 * p_values_index.iloc[:, 3] + 
               3 * p_values_index.iloc[:, 4]) / 11
        
        pivot_table[f'Old_Acl_Val_{year}'] =  acl
        pivot_table[f'Old_Acl_Error_{year}'] =  pivot_table.loc[:, year] - acl
        pivot_table[f'std_dev_{year}'] =  np.std(pivot_table.loc[:, year-5 : year-1].to_numpy(), axis=1)
    queue.put(pivot_table)        
    return pivot_table


def adp_acl_calculation(issue_df, training_year, num_weights, divisor, weights_matrix, num_iterations, year, k):  
    logger = logging.getLogger(__name__)  
    for j in range(num_iterations):        
        quantity_matrix = issue_df[:, j : num_weights + j]         
        acl_constant = weights_matrix * quantity_matrix
        adp_acl = np.sum(acl_constant, axis=1)
        adp_constant = issue_df[:, num_weights + j]
        adp_error = adp_constant - adp_acl
        product = 2 * k * adp_error[:, np.newaxis] * quantity_matrix
        weights_matrix = weights_matrix + product
    return [adp_acl, adp_error, weights_matrix]


def cyclic_loop(issue_df, adp_acl, adp_error, forecast_start, forecast_end, training_year, num_weights, divisor, 
                pivot_table, num_cycles, weights_matrix, num_items, start_year, end_year, k, count, start_time, adp_combine_start, adp_combine_end, queue, name):
    log_file = f"process_{name}.log"
    logging.basicConfig(filename=log_file, level=logging.INFO)  
    logger = logging.getLogger(__name__)    

    for year in range(forecast_start, forecast_end):
        num_iterations = year - (training_year + num_weights)  # Adjust the base year as needed

        e_initial_row = np.array([-1001.0, -1002.0, -1003.0, -1004.0, -1005.0, -1006.0, -1007.0, -1008.0, 1009.0, 897.0])
        
        e_array = np.tile(e_initial_row, (num_items, 1))              
    
        #Divisor Calculation
        con_val  = 0.00000001/divisor
        # print(issue_df)
        count1 = 10
      
        for i in range(num_cycles):
            if(i == count1):
                time = datetime.now()
                # print(name)
                # print(str(count1)+ ":" + str(time - start_time))
                logger.info(f"Name: {name}")
                logger.debug(f"Time since start: {datetime.now() - start_time}")
                logger.info(str(count1)+ ":" + str(time - start_time))
                count1 = count1 * 10            
            adp_acl, adp_error, weights_matrix = adp_acl_calculation(issue_df, training_year, num_weights, divisor, weights_matrix, num_iterations, year, k) 
            # print(adp_acl, adp_error, weights_matrix)
                

            e_array = np.concatenate((e_array[:, -1:], e_array[:, :-1]), axis=1)
            
            # Assign the value of Adap_ACL to the first column of the array
            e_array[:, 0] = adp_acl
            
            # Compute absolute differences between consecutive elements
            abs_diff = np.abs(np.diff(e_array))
            
            # Check if all absolute differences are less than con_val
            if np.all(abs_diff < con_val):
                end_time = datetime.now()
                print(end_time - start_time)
                print(f'{count} no of Cycles = {i}')
                count += 1
                break
                
        
        adp_acl_matrix = issue_df[:, ((year - training_year) - num_weights) : (year - training_year)]
        
        adp_acl_constant = weights_matrix *  adp_acl_matrix 
        
        adp_acl = np.sum(adp_acl_constant, axis=1)
            
        adp_acl[adp_acl < 0] = 0
    
        adp_error_input = issue_df[:,  (year - training_year)]
    
        adp_error = adp_error_input - adp_acl
    
        pivot_table[f'Adp_Acl_Val_{year}'] =  adp_acl * divisor
        pivot_table[f'Adp_Acl_Error_{year}'] =  adp_error * divisor
        

        if(year >= adp_combine_start and year <= adp_combine_end):
            total_combined_acl = 0
            for i in range(year+1, adp_combine_end):
                # print(year)
                # print(i)
                adp_acl_combined_matrix = issue_df[:, ((i - training_year) - num_weights) : ((i - training_year))]
                # print(adp_acl_combined_matrix)
                
                adp_acl_combined_constant = weights_matrix *  adp_acl_combined_matrix 
                
                adp_acl_combined = np.sum(adp_acl_combined_constant, axis=1)
                total_combined_acl += adp_acl_combined * divisor
                    
                # print(adp_acl_combined)
                # print(total_combined_acl)

                # pivot_table[f'Adap_ACL__{year}_{i}'] = adp_acl_combined * divisor
                pivot_table[f'Adap_ACL__{year}_{i}'] = total_combined_acl

    current_folder = os.getcwd()
    path_to_output = os.path.join(current_folder, "output")
    if not os.path.exists(path_to_output):
        os.makedirs(path_to_output)
    
    pivot_table.to_excel(os.path.join(path_to_output, f'Adp_Acl_{forecast_start}_{name}.xlsx'),index = False, index_label = False)
    end_time = datetime.now()
    print(end_time - start_time)
    logger.info(f"Pivot Table: {pivot_table}")
    queue.put(pivot_table)
    return pivot_table




def main(): 
    num_items = 0
    start_year = 2000
    end_year = 2023
    training_year = 2005
    num_weights = 8
    initial_value = 1/num_weights
    divisor = 10
    forecast_start = 2016
    forecast_end = 2023
    adp_combine_start = 2018
    adp_combine_end = 2024
    k = 0.01
    num_cycles = 20000000
    # num_cycles = 1
    count = 1
    
    # ARIMA Parameters
    start_p = 1
    start_q = 1 
    max_p = 20 
    max_q = 20 
    m = 1 
    start_P = 0 
    seasonal = False 
    d = None 
    D = 1 
    trace = True 
    error_action = 'ignore' 
    suppress_warnings = True 
    stepwise = False
    n_jobs = -1


    # Holt Parameters
    Tsb_alpha = 0.9
    season_length = 0
    error_type = 'A'
    h = 1
    alpha_p = 0.5


    #Best Method
    no_of_years = 5
    
    start_time = datetime.now()
    print(start_time)
    
    
    # Step 1: Read the Excel file into a Pandas DataFrame
    # df = pd.read_excel('D:\\Shreejay\\Projects\\MO\\ACL\\output\\issue.xlsx')
    # df = pd.read_excel('D:\\Shreejay\\Projects\\MO\\ACLProject\\input\\Input_test_data_110723.xlsx')
    # df = pd.read_excel('D:\\Shreejay\\Projects\\MO\\ACLProject\\input\\Input_test_data_110723_lead.xlsx')
    # df = pd.read_excel('D:\\Shreejay\\Projects\\MO\\ACLProject\\input\\Input_test_data_110723_lead.xlsx')
    # df = pd.read_excel('C:\\Shreejay\\ACL Generation\\input\\Input_test_data_110723.xlsx')
    # df_grouped = pd.read_excel('C:\\Shreejay\\ACL Generation\\Original\\input\\Dem_data_test_section.xlsx')
    df_grouped = pd.read_excel('C:\\Shreejay\\ACL Generation\\input\\Dem_data_test_section.xlsx')
    df = df_grouped.groupby(['ItemCode', 'Year'])['IssueQty'].sum().reset_index()

    itemcode = df_grouped['ItemCode'].unique()
    years = list(range(start_year, end_year))
    smallest_pos_num = np.finfo(float).eps
    
    all_combinations = pd.MultiIndex.from_product([itemcode, years], names=['ItemCode', 'Year']).to_frame(index=False)
    # print(all_combinations)
    values = [0] * len(years)

    df = all_combinations.merge(df, on=['ItemCode', 'Year'], how='left').fillna(smallest_pos_num)
    print(df)
    # df_combined = pd.concat([df_full.set_index('ItemCode'), df.set_index('ItemCode')]).reset_index().sort_values('ItemCode')
    # df = pd.read_excel('D:\\Shreejay\\Projects\\MO\\ACLProject\\input\\Input_test_data_with_lead_time.xlsx')
    # df = pd.read_excel('D:\\Shreejay\\Projects\\MO\\ACLProject\\input\\Input_test_data_matrix.xlsx')
    # df = pd.read_excel('D:\\Shreejay\\Projects\\MO\\ACLProject\\input\\Input_test_data_matrix_different.xlsx')
    # df = pd.read_excel('D:\\Shreejay\\Projects\\MO\\ACLProject\\input\\Input_test_data_matrix_same.xlsx')
    # print(df)
    
    # Pivot the data to arrange it year-wise and item-wise
    # pivot_table = df.pivot_table(index='Item', columns='Year', values='ISSUE')
    # pivot_table = df.pivot_table(index='ItemCode', columns='Year', values='IssueQty')
    pivot_table = df.pivot_table(index='ItemCode', columns='Year', values='IssueQty')
    print(pivot_table)
    # pivot_table = df.pivot_table(index='Year', columns= ['ItemCode'], values=['IssueQty', 'LeadTime'])
    # lead_time = df.groupby('ItemCode')['LeadTime'].mean().reset_index()
    # lead_time['LeadTime'] = np.ceil(lead_time['LeadTime'])
    # # print(lead_time)
    # lead_time.set_index('ItemCode', inplace=True)    
    # # Join the lead_time with pivot_table
    # pivot_table = pivot_table.join(lead_time)    
    # # print(pivot_table)
    # pivot_table.loc[:, pivot_table.columns != 'LeadTime'] = pivot_table.loc[:, pivot_table.columns != 'LeadTime'].add(pivot_table['LeadTime'], axis=0)
    # print(pivot_table)

    df1 = pivot_table.copy()
    df1 = df1.fillna(smallest_pos_num)
    df2 = df1.to_numpy()
    num_cpus = os.cpu_count()
    # print(num_cpus)
    # print(len(df))
    if(num_items == 0):
        num_items = len(df) 

    # print(weights_matrix)
    pivot_table = pivot_table.fillna(0)
    adp_acl = 0
    adp_error = 0
    pivot_table = pivot_table.fillna(smallest_pos_num)
    manager = multiprocessing.Manager()
    result_queue = manager.Queue()



    # print(items_per_process)
    max_pivot = df2[:, (training_year - start_year):(end_year - start_year)]
    # print(max_pivot)
    max_val = max_pivot.max(axis=1)
    # print(max_val)
    q=2
    while q > 1:
        q = (max_val//divisor).any()
        if (q >= 1):
            divisor = divisor * 10
    
    issue_df = df2[:, (training_year - start_year) : (end_year - start_year)]/divisor  
    num_items = len(issue_df)
    
    items_per_process = int(num_items/(num_cpus-2))

    if(items_per_process == 0):
        items_per_process = 1
    # weights_matrix = np.full((int(num_items/2), num_weights), initial_value)
    weights_matrix = np.full((items_per_process, num_weights), initial_value)    
    # print(num_items)
    try:
        i = 0
        args_list = []
        # print(num_cpus)        
        for i in range(num_cpus - 2):
            start_index = i * items_per_process
            # print(start_index)
            # end_index = min((i + 1) * items_per_process, num_items)                 
            end_index = (i + 1) * items_per_process                 
            # print(end_index)
            df_chunk = issue_df[start_index:end_index,:]
            # print(df_chunk)
            pivot_table_chunk = pivot_table.iloc[start_index:end_index]
            weight_matrix = np.full((len(df_chunk), num_weights), initial_value)
            print(len(df_chunk))
            if(len(df_chunk) != 0):
                args = (df_chunk, adp_acl, adp_error, forecast_start, forecast_end, training_year, num_weights, divisor,
                    pivot_table_chunk.copy(), num_cycles, weight_matrix.copy(), items_per_process, start_year, end_year, k, count, start_time,
                    adp_combine_start, adp_combine_end, result_queue, f"process_{i+1}")
                args_list.append(args)
            else:
                break
            # if(df_chunk.empty == False):
            #     args = (df_chunk, adp_acl, adp_error, forecast_start, forecast_end, training_year, num_weights, divisor,
            #         pivot_table_chunk.copy(), num_cycles, weights_matrix.copy(), items_per_process, start_year, end_year, k, count, start_time,
            #         adp_combine_start, adp_combine_end, result_queue, f"process_{i+1}")
            #     args_list.append(args)

        print(len(args_list))
        if(len(args_list) < num_cpus):
            num_cpus = len(args_list)
        else:
            num_cpus = num_cpus - 2

        pool = multiprocessing.Pool(processes= num_cpus)
  
        # Submit tasks to the pool asynchronously
        async_results = pool.starmap_async(cyclic_loop, args_list)
    

        for p in pool._pool:
            process = psutil.Process(p.pid)
            print(f"Process ID: {p.pid}, CPU Affinity: {process.cpu_affinity()}")

        # Wait for all tasks to complete and retrieve results
        results = async_results.get()
        print(results)

        for k in range(0, len(results)):
            for col1 in results[k].columns.tolist():
                quantity = []
                pattern1 = "Adp_Acl"
                if(re.search(pattern1, str(col1))):
                    quantity.append(str(col1))
                    pivot_table.loc[results[k].index, col1] =  results[k][col1]
        print(pivot_table)

        pool.close()
        pool.join()




        num_cpus = os.cpu_count() - 2
        

        pool = multiprocessing.Pool(processes = num_cpus)
  
        # Submit tasks to the pool asynchronously
        fb_prophet_args = (start_year, df, forecast_start, forecast_end, pivot_table, result_queue, f"process_{i+1}", smallest_pos_num)
        fb_prophet_results = pool.apply_async(fb_prophet, fb_prophet_args)        

        vertical_df_args = (df, forecast_start, result_queue, f"process_{i+1}")
        non_zero_item_df_issueNAC = pool.apply_async(vertical_df, vertical_df_args)
        non_zero_item_df_issueNAC = non_zero_item_df_issueNAC.get()

        arima_args = (non_zero_item_df_issueNAC, forecast_start, forecast_end, start_year, adp_combine_start, adp_combine_end, pivot_table, 
        start_p, start_q, max_p, max_q, m, start_P, seasonal, d, D, trace, error_action, suppress_warnings, stepwise, n_jobs, result_queue, f"process_{i+1}")
        arima_results = pool.apply_async(arima, arima_args)

        holt_crostons_args = (non_zero_item_df_issueNAC, Tsb_alpha, season_length, error_type, h, alpha_p, forecast_start, forecast_end, start_year, 
                  adp_combine_start, adp_combine_end, pivot_table, result_queue, f"process_{i+1}")
        holt_crostons_results = pool.apply_async(holt_crostons, holt_crostons_args)

        simple_RNN_args = (start_year, df, forecast_start, forecast_end, pivot_table, result_queue, f"process_{i+1}", smallest_pos_num)
        simple_RNN_results = pool.apply_async(simple_RNN, simple_RNN_args)
        
        old_acl_args = (pivot_table, forecast_start, forecast_end,  result_queue, f"process_{i+1}")
        old_acl_results = pool.apply_async(old_acl_calculation, old_acl_args)


        for p in pool._pool:
            process = psutil.Process(p.pid)
            print(f"Process ID: {p.pid}, CPU Affinity: {process.cpu_affinity()}")

        fb_prophet_result = fb_prophet_results.get()
        arima_result =  arima_results.get()
        holt_crostons_result = holt_crostons_results.get()
        simple_RNN_result = simple_RNN_results.get()
        old_acl_result = old_acl_results.get()

        # dataframe = pd.DataFrame(pivot_table)
        # print("non_zero_item_df_issueNAC : ", non_zero_item_df_issueNAC)
        # print("arima_result : ", arima_result)
        # print("holt_crostons_result : ", holt_crostons_result)
        # print("simple_RNN_result : ", simple_RNN_result)
        # print("old_acl_result : ", old_acl_result)


        # print(fb_prophet_result.columns.tolist)
        # for index, row in pivot_table.iterrows():
        # patterns = ["Adp_Acl", "FB_Prophet", "ARIMA", "Holt", "TSB", "Simple_RNN", "Old_Acl"]
        # for pattern in patterns:
        # print(dataframe)



        for col1 in fb_prophet_result.columns.tolist():
            quantity = []
            pattern1 = "FB_Prophet"
            if(re.search(pattern1, str(col1))):
                quantity.append(str(col1))
                pivot_table[col1] =  fb_prophet_result[col1]
        for col1 in arima_result.columns.tolist():
            quantity = []
            pattern2 = "ARIMA"
            if(re.search(pattern2, str(col1))):
                quantity.append(str(col1))
                pivot_table[col1] =  arima_result[col1]
        for col1 in holt_crostons_result.columns.tolist():
            quantity = []
            pattern3 = "Holt"
            if(re.search(pattern3, str(col1))):
                quantity.append(str(col1))
                pivot_table[col1] =  holt_crostons_result[col1]
        for col1 in holt_crostons_result.columns.tolist():
            quantity = []
            pattern4 = "TSB"
            if(re.search(pattern4, str(col1))):
                quantity.append(str(col1))
                pivot_table[col1] =  holt_crostons_result[col1]
        for col1 in simple_RNN_result.columns.tolist():
            quantity = []
            pattern5 = "Simple_RNN"
            if(re.search(pattern5, str(col1))):
                quantity.append(str(col1))
                pivot_table[col1] =  simple_RNN_result[col1]
        for col1 in old_acl_result.columns.tolist():
            quantity = []
            pattern6 = "Old_Acl"
            if(re.search(pattern6, str(col1))):
                quantity.append(str(col1))
                pivot_table[col1] =  old_acl_result[col1]
        print(pivot_table)

        # print(quantity)
            # min = []
            # cols = []
            # for year in range(forecast_start, forecast_start+no_of_years):
            #     error_pattern = f"Error_{year}"  # Matches "Error" followed by optional digit
            #     for col in quantity:
            #         if(re.search(error_pattern, col)):
            #             cols.append(col)


        # pivot_table = 
        # print(arima_results.get())
        # print(holt_crostons_results.get())
        # print(simple_RNN_results.get())
        # print(old_acl_results.get())

        # Wait for all tasks to complete and retrieve results


        # print("fb_prophet_result : ", fb_prophet_result)

        # pool.close()
        # pool.join()



        # num_cpus = os.cpu_count() - 2
        

        # pool = multiprocessing.Pool(processes= num_cpus)


        combined_method_args = (pivot_table, forecast_start, forecast_end, result_queue, f"process_{i+1}")
        combined_method_results = pool.apply_async(combined_method, combined_method_args)




        combined_method_result =  combined_method_results.get()

        for col1 in combined_method_result.columns.tolist():
            quantity = []
            pattern1 = "Combined"
            if(re.search(pattern1, str(col1))):
                quantity.append(str(col1))
                pivot_table[col1] =  combined_method_result[col1]

        find_best_method_per_year_args = (pivot_table, forecast_start, forecast_end, result_queue, f"process_{i+1}")
        find_best_method_per_year_results = pool.apply_async(find_best_method_per_year, find_best_method_per_year_args)


        find_combined_error_args = (pivot_table, forecast_start, forecast_end, no_of_years, result_queue, f"process_{i+1}")
        find_combined_error_results = pool.apply_async(find_combined_error, find_combined_error_args)

        for p in pool._pool:
            process = psutil.Process(p.pid)
            print(f"Process ID: {p.pid}, CPU Affinity: {process.cpu_affinity()}")

        find_best_method_per_year_result = find_best_method_per_year_results.get()
        find_combined_error_result = find_combined_error_results.get()

        for col1 in find_best_method_per_year_result.columns.tolist():
            quantity = []
            pattern2 = "Best_of_"
            if(re.search(pattern2, str(col1))):
                quantity.append(str(col1))
                pivot_table[col1] =  find_best_method_per_year_result[col1]
        for col1 in find_combined_error_result.columns.tolist():
            quantity = []
            pattern3 = "_CombineError_"
            if(re.search(pattern3, str(col1))):
                quantity.append(str(col1))
                pivot_table[col1] =  find_combined_error_result[col1]


        find_best_combined_method_args = (pivot_table, forecast_start, forecast_end, no_of_years, result_queue, f"process_{i+1}")
        find_best_combined_method_results = pool.apply_async(find_best_combined_method, find_best_combined_method_args)
        find_best_combined_method_result = find_best_combined_method_results.get()



        for col1 in find_best_combined_method_result.columns.tolist():
            quantity = []
            pattern4 = "Best_of_"
            if(re.search(pattern4, str(col1))):
                quantity.append(str(col1))
                pivot_table[col1] =  find_best_combined_method_result[col1]


        current_folder = os.getcwd()
        path_to_output = os.path.join(current_folder, "output")
        if not os.path.exists(path_to_output):
            os.makedirs(path_to_output)
        
        pivot_table.to_excel(os.path.join(path_to_output, f'Multiprocessing_Results_{forecast_start}_{forecast_end}.xlsx'),index = False, index_label = False)




        print("combined_method_result : ", combined_method_result)
        print("find_best_method_per_year_result : ", find_best_method_per_year_result)
        print("find_combined_error_result : ", find_combined_error_result)
        print("find_best_combined_method_result : ", find_best_combined_method_result)


        # wait(async_results)
        # print(len(results))
        # results = [async_result.get() for async_result in async_results]
    
        # ... process results or use them in further calculations ...
        pool.close()
        pool.join()

    except Exception as e:
        print(e)

    # starting process 1
    # starting process 2
        
    # wait until process 1 is finished
    # wait until process 2 is finished
    # pivot_table = fb_prophet(start_year, forecast_start, forecast_end, pivot_table)
    # non_zero_item_df_issueNAC = vertical_df(df, forecast_start);
    # pivot_table = arima(non_zero_item_df_issueNAC, forecast_start, forecast_end, start_year, adp_combine_start, adp_combine_end, pivot_table, 
    #        start_p, start_q, max_p, max_q, m, start_P, seasonal, d, D, trace, error_action, suppress_warnings, stepwise, n_jobs)
    # pivot_table = holt_crostons(non_zero_item_df_issueNAC, Tsb_alpha, season_length, error_type, h, alpha_p, forecast_start, forecast_end, start_year, 
    #               adp_combine_start, adp_combine_end, pivot_table)
    # pivot_table = simple_RNN(start_year, forecast_start, forecast_end, pivot_table)
    # pivot_table = old_acl_calculation(pivot_table, forecast_start, forecast_end)
    # pivot_table = combined_method(pivot_table, forecast_start, forecast_end)
    # pivot_table = find_best_method_per_year(pivot_table, forecast_start, forecast_end)    
    # pivot_table = find_combined_error(pivot_table, forecast_start, forecast_end, no_of_years)    
    # find_best_combined_method(pivot_table, forecast_start, forecast_end, no_of_years)

    current_folder = os.getcwd()
    path_to_output = os.path.join(current_folder, "output")
    if not os.path.exists(path_to_output):
        os.makedirs(path_to_output)
    
    pivot_table.to_excel(os.path.join(path_to_output, f'Overall_Results_{forecast_start}.xlsx'),index = False, index_label = False)
    end_time = datetime.now()
    print(end_time - start_time)
    # print(pivot_table1)
    # print(pivot_table2)

if __name__ == '__main__':
    main()


